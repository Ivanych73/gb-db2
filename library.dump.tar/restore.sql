--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.2
-- Dumped by pg_dump version 14.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET escape_string_warning = off;
SET row_security = off;

DROP DATABASE library;
--
-- Name: library; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE library WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'ru_RU.UTF-8';


ALTER DATABASE library OWNER TO postgres;

\connect library

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET escape_string_warning = off;
SET row_security = off;

--
-- Name: isn; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS isn WITH SCHEMA public;


--
-- Name: EXTENSION isn; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION isn IS 'data types for international product numbering standards';


--
-- Name: file_type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.file_type AS ENUM (
    'annotation',
    'content',
    'biography'
);


ALTER TYPE public.file_type OWNER TO postgres;

--
-- Name: create_chat_on_create_entity_trigger(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.create_chat_on_create_entity_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
	DECLARE 
		new_chat_title VARCHAR(128);
		new_chat_id INTEGER;
	
	BEGIN
        IF TG_TABLE_NAME = 'books'
        THEN new_chat_title := 'Впечатления читателей от книги '|| NEW.title;
        ELSE new_chat_title := 'Обсуждение новости  '|| NEW.title;
		END IF;
        INSERT INTO chats ("title", "create_date") VALUES (new_chat_title, (select current_date));
        new_chat_id := (SELECT id FROM CHATS WHERE title = new_chat_title ORDER BY id DESC LIMIT 1);
        NEW.chat_id = new_chat_id;
        RETURN NEW;
	END
$$;


ALTER FUNCTION public.create_chat_on_create_entity_trigger() OWNER TO postgres;

--
-- Name: create_message_on_create_book_trigger(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.create_message_on_create_book_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
    DECLARE 
        chat_id INTEGER;
        admin_id INTEGER;
        text VARCHAR(255);
	BEGIN
        chat_id := (SELECT id FROM chats WHERE title = 'Новые книги в нашей библиотеке');
        admin_id := (SELECT id FROM users WHERE login = 'administrator');
        text := 'Добавлена новая книга ' || NEW.title;
        INSERT INTO messages (author_id, create_date, chat_id, body)
            VALUES (admin_id, (select current_date), chat_id, text);
        RETURN NEW;
	END
$$;


ALTER FUNCTION public.create_message_on_create_book_trigger() OWNER TO postgres;

--
-- Name: create_message_on_create_news_trigger(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.create_message_on_create_news_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
    DECLARE 
        chat_id INTEGER;
        admin_id INTEGER;
	BEGIN
        chat_id := (SELECT id FROM chats WHERE title = 'Новости портала');
        admin_id := (SELECT id FROM users WHERE login = 'administrator');
        INSERT INTO messages (author_id, create_date, chat_id, body)
            VALUES (admin_id, (select current_date), chat_id, NEW.title);
        RETURN NEW;
	END
$$;


ALTER FUNCTION public.create_message_on_create_news_trigger() OWNER TO postgres;

--
-- Name: delete_annotation_content_on_delete_book_trigger(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.delete_annotation_content_on_delete_book_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
	BEGIN
        DELETE FROM files WHERE id = OLD.annotation_file_id;
        DELETE FROM files WHERE id = OLD.content_file_id;
        RETURN OLD;
	END
$$;


ALTER FUNCTION public.delete_annotation_content_on_delete_book_trigger() OWNER TO postgres;

--
-- Name: delete_chat_on_delete_entity_trigger(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.delete_chat_on_delete_entity_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
	BEGIN
        DELETE FROM chats WHERE id = OLD.chat_id;
        RETURN OLD;
	END
$$;


ALTER FUNCTION public.delete_chat_on_delete_entity_trigger() OWNER TO postgres;

--
-- Name: delete_contacts_on_delete_entity_trigger(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.delete_contacts_on_delete_entity_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
	BEGIN
        DELETE FROM contacts WHERE id = OLD.contacts_id;
        RETURN OLD;
	END
$$;


ALTER FUNCTION public.delete_contacts_on_delete_entity_trigger() OWNER TO postgres;

--
-- Name: delete_pseudonyms_biography_on_delete_autor_trigger(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.delete_pseudonyms_biography_on_delete_autor_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
	BEGIN
        DELETE FROM pseudonyms WHERE author_id = OLD.id;
        DELETE FROM files WHERE id = OLD.biography_file_id;
        RETURN OLD;
	END
$$;


ALTER FUNCTION public.delete_pseudonyms_biography_on_delete_autor_trigger() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: authors; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.authors (
    id integer NOT NULL,
    first_name character varying(25) NOT NULL,
    last_name character varying(25),
    biography_file_id bigint,
    contacts_id bigint
);


ALTER TABLE public.authors OWNER TO postgres;

--
-- Name: authors_books; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.authors_books (
    author_id bigint NOT NULL,
    book_id bigint NOT NULL
);


ALTER TABLE public.authors_books OWNER TO postgres;

--
-- Name: authors_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.authors_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.authors_id_seq OWNER TO postgres;

--
-- Name: authors_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.authors_id_seq OWNED BY public.authors.id;


--
-- Name: books; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.books (
    id integer NOT NULL,
    title character varying(200) NOT NULL,
    isbn public.isbn13,
    publish_date date NOT NULL,
    annotation_file_id bigint,
    content_file_id bigint NOT NULL,
    add_to_library_date date NOT NULL,
    chat_id bigint NOT NULL,
    genre_id bigint,
    added_by_id bigint,
    average_rating real,
    votes_count bigint,
    series_id bigint
);


ALTER TABLE public.books OWNER TO postgres;

--
-- Name: book_chats; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.book_chats AS
 SELECT books.chat_id
   FROM public.books;


ALTER TABLE public.book_chats OWNER TO postgres;

--
-- Name: books_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.books_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.books_id_seq OWNER TO postgres;

--
-- Name: books_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.books_id_seq OWNED BY public.books.id;


--
-- Name: books_voters; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.books_voters (
    book_id bigint NOT NULL,
    voter_id bigint NOT NULL
);


ALTER TABLE public.books_voters OWNER TO postgres;

--
-- Name: chats; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.chats (
    id integer NOT NULL,
    title character varying(128) NOT NULL,
    create_date date NOT NULL,
    created_by_id bigint
);


ALTER TABLE public.chats OWNER TO postgres;

--
-- Name: chats_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.chats_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.chats_id_seq OWNER TO postgres;

--
-- Name: chats_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.chats_id_seq OWNED BY public.chats.id;


--
-- Name: contacts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.contacts (
    id integer NOT NULL,
    email character varying(64) NOT NULL,
    phone character varying(13),
    whatsapp character varying(13),
    telegram character varying(64),
    web_site character varying(64)
);


ALTER TABLE public.contacts OWNER TO postgres;

--
-- Name: contacts_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.contacts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.contacts_id_seq OWNER TO postgres;

--
-- Name: contacts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.contacts_id_seq OWNED BY public.contacts.id;


--
-- Name: files; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.files (
    id integer NOT NULL,
    file_path character varying(256) NOT NULL,
    file_type public.file_type NOT NULL,
    file_size smallint NOT NULL
);


ALTER TABLE public.files OWNER TO postgres;

--
-- Name: files_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.files_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.files_id_seq OWNER TO postgres;

--
-- Name: files_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.files_id_seq OWNED BY public.files.id;


--
-- Name: genres; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.genres (
    id integer NOT NULL,
    title character varying(64) NOT NULL
);


ALTER TABLE public.genres OWNER TO postgres;

--
-- Name: genres_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.genres_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.genres_id_seq OWNER TO postgres;

--
-- Name: genres_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.genres_id_seq OWNED BY public.genres.id;


--
-- Name: messages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.messages (
    id integer NOT NULL,
    author_id bigint NOT NULL,
    create_date date NOT NULL,
    chat_id bigint NOT NULL,
    body text NOT NULL
);


ALTER TABLE public.messages OWNER TO postgres;

--
-- Name: messages_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.messages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.messages_id_seq OWNER TO postgres;

--
-- Name: messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.messages_id_seq OWNED BY public.messages.id;


--
-- Name: most_discussed_genre; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.most_discussed_genre AS
 SELECT count(messages.id) AS count,
    genres.title
   FROM ((public.messages
     JOIN public.books ON ((messages.chat_id = books.chat_id)))
     JOIN public.genres ON ((books.genre_id = genres.id)))
  WHERE (messages.chat_id IN ( SELECT book_chats.chat_id
           FROM public.book_chats))
  GROUP BY genres.title
  ORDER BY (count(messages.id)) DESC
 LIMIT 1;


ALTER TABLE public.most_discussed_genre OWNER TO postgres;

--
-- Name: news; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.news (
    id integer NOT NULL,
    title character varying(256) NOT NULL,
    body text NOT NULL,
    chat_id bigint
);


ALTER TABLE public.news OWNER TO postgres;

--
-- Name: news_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.news_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.news_id_seq OWNER TO postgres;

--
-- Name: news_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.news_id_seq OWNED BY public.news.id;


--
-- Name: pseudonyms; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pseudonyms (
    id integer NOT NULL,
    pseudonym character varying(25) NOT NULL,
    author_id bigint NOT NULL
);


ALTER TABLE public.pseudonyms OWNER TO postgres;

--
-- Name: pseudonyms_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.pseudonyms_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.pseudonyms_id_seq OWNER TO postgres;

--
-- Name: pseudonyms_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.pseudonyms_id_seq OWNED BY public.pseudonyms.id;


--
-- Name: series; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.series (
    id integer NOT NULL,
    title character varying(256) NOT NULL
);


ALTER TABLE public.series OWNER TO postgres;

--
-- Name: series_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.series_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.series_id_seq OWNER TO postgres;

--
-- Name: series_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.series_id_seq OWNED BY public.series.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id integer NOT NULL,
    login character varying(25) NOT NULL,
    registration_date date NOT NULL,
    password_hash character varying(128) NOT NULL,
    contacts_id bigint
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: authors id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.authors ALTER COLUMN id SET DEFAULT nextval('public.authors_id_seq'::regclass);


--
-- Name: books id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.books ALTER COLUMN id SET DEFAULT nextval('public.books_id_seq'::regclass);


--
-- Name: chats id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.chats ALTER COLUMN id SET DEFAULT nextval('public.chats_id_seq'::regclass);


--
-- Name: contacts id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contacts ALTER COLUMN id SET DEFAULT nextval('public.contacts_id_seq'::regclass);


--
-- Name: files id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.files ALTER COLUMN id SET DEFAULT nextval('public.files_id_seq'::regclass);


--
-- Name: genres id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.genres ALTER COLUMN id SET DEFAULT nextval('public.genres_id_seq'::regclass);


--
-- Name: messages id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages ALTER COLUMN id SET DEFAULT nextval('public.messages_id_seq'::regclass);


--
-- Name: news id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.news ALTER COLUMN id SET DEFAULT nextval('public.news_id_seq'::regclass);


--
-- Name: pseudonyms id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pseudonyms ALTER COLUMN id SET DEFAULT nextval('public.pseudonyms_id_seq'::regclass);


--
-- Name: series id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.series ALTER COLUMN id SET DEFAULT nextval('public.series_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: authors; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.authors (id, first_name, last_name, biography_file_id, contacts_id) FROM stdin;
\.
COPY public.authors (id, first_name, last_name, biography_file_id, contacts_id) FROM '$$PATH$$/4555.dat';

--
-- Data for Name: authors_books; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.authors_books (author_id, book_id) FROM stdin;
\.
COPY public.authors_books (author_id, book_id) FROM '$$PATH$$/4566.dat';

--
-- Data for Name: books; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.books (id, title, isbn, publish_date, annotation_file_id, content_file_id, add_to_library_date, chat_id, genre_id, added_by_id, average_rating, votes_count, series_id) FROM stdin;
\.
COPY public.books (id, title, isbn, publish_date, annotation_file_id, content_file_id, add_to_library_date, chat_id, genre_id, added_by_id, average_rating, votes_count, series_id) FROM '$$PATH$$/4565.dat';

--
-- Data for Name: books_voters; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.books_voters (book_id, voter_id) FROM stdin;
\.
COPY public.books_voters (book_id, voter_id) FROM '$$PATH$$/4567.dat';

--
-- Data for Name: chats; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.chats (id, title, create_date, created_by_id) FROM stdin;
\.
COPY public.chats (id, title, create_date, created_by_id) FROM '$$PATH$$/4559.dat';

--
-- Data for Name: contacts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.contacts (id, email, phone, whatsapp, telegram, web_site) FROM stdin;
\.
COPY public.contacts (id, email, phone, whatsapp, telegram, web_site) FROM '$$PATH$$/4551.dat';

--
-- Data for Name: files; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.files (id, file_path, file_type, file_size) FROM stdin;
\.
COPY public.files (id, file_path, file_type, file_size) FROM '$$PATH$$/4549.dat';

--
-- Data for Name: genres; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.genres (id, title) FROM stdin;
\.
COPY public.genres (id, title) FROM '$$PATH$$/4545.dat';

--
-- Data for Name: messages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.messages (id, author_id, create_date, chat_id, body) FROM stdin;
\.
COPY public.messages (id, author_id, create_date, chat_id, body) FROM '$$PATH$$/4561.dat';

--
-- Data for Name: news; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.news (id, title, body, chat_id) FROM stdin;
\.
COPY public.news (id, title, body, chat_id) FROM '$$PATH$$/4563.dat';

--
-- Data for Name: pseudonyms; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pseudonyms (id, pseudonym, author_id) FROM stdin;
\.
COPY public.pseudonyms (id, pseudonym, author_id) FROM '$$PATH$$/4557.dat';

--
-- Data for Name: series; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.series (id, title) FROM stdin;
\.
COPY public.series (id, title) FROM '$$PATH$$/4547.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, login, registration_date, password_hash, contacts_id) FROM stdin;
\.
COPY public.users (id, login, registration_date, password_hash, contacts_id) FROM '$$PATH$$/4553.dat';

--
-- Name: authors_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.authors_id_seq', 52, true);


--
-- Name: books_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.books_id_seq', 548, true);


--
-- Name: chats_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.chats_id_seq', 585, true);


--
-- Name: contacts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.contacts_id_seq', 150, true);


--
-- Name: files_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.files_id_seq', 1146, true);


--
-- Name: genres_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.genres_id_seq', 20, true);


--
-- Name: messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.messages_id_seq', 16302, true);


--
-- Name: news_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.news_id_seq', 38, true);


--
-- Name: pseudonyms_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.pseudonyms_id_seq', 10, true);


--
-- Name: series_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.series_id_seq', 40, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 120, true);


--
-- Name: authors_books authors_books_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.authors_books
    ADD CONSTRAINT authors_books_pkey PRIMARY KEY (author_id, book_id);


--
-- Name: authors authors_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.authors
    ADD CONSTRAINT authors_pkey PRIMARY KEY (id);


--
-- Name: books books_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.books
    ADD CONSTRAINT books_pkey PRIMARY KEY (id);


--
-- Name: books_voters books_voters_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.books_voters
    ADD CONSTRAINT books_voters_pkey PRIMARY KEY (voter_id, book_id);


--
-- Name: chats chats_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.chats
    ADD CONSTRAINT chats_pkey PRIMARY KEY (id);


--
-- Name: contacts contacts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contacts
    ADD CONSTRAINT contacts_pkey PRIMARY KEY (id);


--
-- Name: files files_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.files
    ADD CONSTRAINT files_pkey PRIMARY KEY (id);


--
-- Name: genres genres_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.genres
    ADD CONSTRAINT genres_pkey PRIMARY KEY (id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id);


--
-- Name: news news_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.news
    ADD CONSTRAINT news_pkey PRIMARY KEY (id);


--
-- Name: pseudonyms pseudonyms_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pseudonyms
    ADD CONSTRAINT pseudonyms_pkey PRIMARY KEY (id);


--
-- Name: series series_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.series
    ADD CONSTRAINT series_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: books_genre_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX books_genre_id_idx ON public.books USING btree (genre_id);


--
-- Name: books create_chat_on_create_book; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER create_chat_on_create_book BEFORE INSERT ON public.books FOR EACH ROW EXECUTE FUNCTION public.create_chat_on_create_entity_trigger();


--
-- Name: news create_chat_on_create_news; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER create_chat_on_create_news BEFORE INSERT ON public.news FOR EACH ROW EXECUTE FUNCTION public.create_chat_on_create_entity_trigger();


--
-- Name: books create_message_on_create_book; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER create_message_on_create_book BEFORE INSERT ON public.books FOR EACH ROW EXECUTE FUNCTION public.create_message_on_create_book_trigger();


--
-- Name: news create_message_on_create_news; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER create_message_on_create_news BEFORE INSERT ON public.news FOR EACH ROW EXECUTE FUNCTION public.create_message_on_create_news_trigger();


--
-- Name: books delete_annotation_content_on_delete_book; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER delete_annotation_content_on_delete_book AFTER DELETE ON public.books FOR EACH ROW EXECUTE FUNCTION public.delete_annotation_content_on_delete_book_trigger();


--
-- Name: books delete_chat_on_delete_book; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER delete_chat_on_delete_book AFTER DELETE ON public.books FOR EACH ROW EXECUTE FUNCTION public.delete_chat_on_delete_entity_trigger();


--
-- Name: news delete_chat_on_delete_news; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER delete_chat_on_delete_news AFTER DELETE ON public.news FOR EACH ROW EXECUTE FUNCTION public.delete_chat_on_delete_entity_trigger();


--
-- Name: authors delete_contacts_on_delete_author; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER delete_contacts_on_delete_author AFTER DELETE ON public.authors FOR EACH ROW EXECUTE FUNCTION public.delete_contacts_on_delete_entity_trigger();


--
-- Name: users delete_contacts_on_delete_user; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER delete_contacts_on_delete_user AFTER DELETE ON public.users FOR EACH ROW EXECUTE FUNCTION public.delete_contacts_on_delete_entity_trigger();


--
-- Name: authors delete_pseudonyms_biography_on_delete_autor; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER delete_pseudonyms_biography_on_delete_autor AFTER DELETE ON public.authors FOR EACH ROW EXECUTE FUNCTION public.delete_pseudonyms_biography_on_delete_autor_trigger();


--
-- Name: books added_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.books
    ADD CONSTRAINT added_by_id_fk FOREIGN KEY (added_by_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: books annotation_file_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.books
    ADD CONSTRAINT annotation_file_id_fk FOREIGN KEY (annotation_file_id) REFERENCES public.files(id) ON DELETE SET NULL;


--
-- Name: pseudonyms author_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pseudonyms
    ADD CONSTRAINT author_id_fk FOREIGN KEY (author_id) REFERENCES public.authors(id) ON DELETE CASCADE;


--
-- Name: messages author_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT author_id_fk FOREIGN KEY (author_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: authors_books author_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.authors_books
    ADD CONSTRAINT author_id_fk FOREIGN KEY (author_id) REFERENCES public.authors(id) ON DELETE CASCADE;


--
-- Name: authors_books book_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.authors_books
    ADD CONSTRAINT book_id_fk FOREIGN KEY (book_id) REFERENCES public.books(id) ON DELETE CASCADE;


--
-- Name: books_voters book_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.books_voters
    ADD CONSTRAINT book_id_fk FOREIGN KEY (book_id) REFERENCES public.books(id) ON DELETE CASCADE;


--
-- Name: messages chat_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT chat_id_fk FOREIGN KEY (chat_id) REFERENCES public.chats(id) ON DELETE CASCADE;


--
-- Name: news chat_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.news
    ADD CONSTRAINT chat_id_fk FOREIGN KEY (chat_id) REFERENCES public.chats(id) ON DELETE SET NULL;


--
-- Name: books chat_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.books
    ADD CONSTRAINT chat_id_fk FOREIGN KEY (chat_id) REFERENCES public.chats(id) ON DELETE RESTRICT;


--
-- Name: users contacts_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT contacts_id_fk FOREIGN KEY (contacts_id) REFERENCES public.contacts(id) ON DELETE SET NULL;


--
-- Name: authors contacts_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.authors
    ADD CONSTRAINT contacts_id_fk FOREIGN KEY (contacts_id) REFERENCES public.contacts(id) ON DELETE SET NULL;


--
-- Name: books content_file_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.books
    ADD CONSTRAINT content_file_id_fk FOREIGN KEY (content_file_id) REFERENCES public.files(id) ON DELETE CASCADE;


--
-- Name: chats created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.chats
    ADD CONSTRAINT created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: books genre_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.books
    ADD CONSTRAINT genre_id_fk FOREIGN KEY (genre_id) REFERENCES public.genres(id) ON DELETE SET NULL;


--
-- Name: books series_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.books
    ADD CONSTRAINT series_id_fk FOREIGN KEY (series_id) REFERENCES public.series(id) ON DELETE SET NULL;


--
-- Name: books_voters voter_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.books_voters
    ADD CONSTRAINT voter_id_fk FOREIGN KEY (voter_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

